// Wait for element
function waitForElement(cssSelector, callback, waitTime) {
	var stop,
		elementCached,
		timeout,
		check = function () {
			try {
				elementCached = document.querySelector(cssSelector);

				if (stop) return;

				if (elementCached) {
					callback(elementCached);
					clearTimeout(timeout);
				} else {
					window.requestAnimationFrame(check);
				}
			} catch (err) {
				console.log(err);
			}
		};
	window.requestAnimationFrame(check);

	timeout = setTimeout(function () {
		stop = true;
	}, waitTime);
}

waitForElement('#___gatsby main', runObserverOnMain, 5000);

function runObserverOnMain() {
	const targetNode = document.querySelector("#___gatsby main");
	const config = {
		attributes: true,
		childList: true,
		subtree: false
	};
	const callback = (mutationList, observer) => {
		console.log("5001::runObserverOnMain");
		beforLoadTestCode5001();
	};
	const observer = new MutationObserver(callback);
	observer.observe(targetNode, config);
	beforLoadTestCode5001();
}

function beforLoadTestCode5001() {
	console.log("5001::beforLoadTestCode5001");
	if (window.location.href.indexOf('/pricing') == -1) {
		document.querySelector("body").classList.remove("spz_5001");
		return;
	}
	var loadTestInterval = setInterval(loadTestCode5001, 200);
	setTimeout(function () {
		clearInterval(loadTestInterval);
	}, 2000);

}

const loadJS_SPZ = (url, implementationCode, location) => {
	var scriptTag = document.createElement("script");
	scriptTag.src = url;

	scriptTag.onload = implementationCode;
	scriptTag.onreadystatechange = implementationCode;

	location.appendChild(scriptTag);
};
const loadCSS_SPZ = (path) => {
	let css = document.createElement("link");
	css.rel = "stylesheet";
	css.media = "all";
	css.href = path;

	document.getElementsByTagName("head")[0].appendChild(css);
};

const smoothScrollJSURL = "//res.cloudinary.com/spiralyze/raw/upload/v1710416831/assembly/script/smooth-scroll.min.js";
const splideCSSURL = "//cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css";
const splideJSURL = "//cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js";

loadJS_SPZ(smoothScrollJSURL, function () {}, document.body);
loadCSS_SPZ(splideCSSURL);


// Add new main hero if page does not have
if(!document.querySelector('.spz_7001 .main_hero')){
  document.querySelector("main").insertAdjacentHTML(
    "afterbegin",
    `
      <div class="main_hero">
        Your HTML
      </div>
    `
  );
}