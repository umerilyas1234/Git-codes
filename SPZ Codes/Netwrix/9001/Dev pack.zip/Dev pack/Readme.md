// Build File notes 

// 1. Replace HTML as shown in the screenshot as we redesign page.: 
// 2. Add CSS file at the end of your current CSS file. You can filter some of CSS if it is already available in live page.
// 3. You can remove body class from the CSS. We used it for overwrite our CSS for designing.
// 4. Please add JavaScript at the end of the custom javascript file.
// 5. Please upload all Images/font family in your server and attach it with the page. Do not use cloudinary URL. You can find the font file in Images/Fonts folder respectively.

// Build File notes over