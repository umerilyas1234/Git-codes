// main css
var link = document.createElement("link");
link.rel = "stylesheet";
link.type = "text/css";
link.href =
  "https://res.cloudinary.com/spiralyze/raw/upload/v1707830303/JupiterOne/5006/src/style.css";
if (
  !document.querySelector(
    'link[href="https://res.cloudinary.com/spiralyze/raw/upload/v1707830303/JupiterOne/5006/src/style.css"]'
  )
) {
  document.getElementsByTagName("head")[0].appendChild(link);
}

function loadTestCode() {
  if (!document.querySelector("body").classList.contains("spz_50061")) {
    document.querySelector("body").classList.add("spz_50061");
    
  }
}

var bodyInterval = setInterval(() => {
  if (document.querySelectorAll("body").length > 0) {
    clearInterval(bodyInterval);
    loadTestCode();
  }
}, 100);
