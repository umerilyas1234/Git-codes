function loadTestCode7001() {
  if (!document.querySelector("body").classList.contains("spz_7001")) {
    document.querySelector("body").classList.add("spz_7001");
  }
}

var bodyInterval = setInterval(() => {
  if (document.querySelectorAll("body").length > 0) {
    clearInterval(bodyInterval);
    const targetNode = document.querySelector("html");
    const config = { attributes: true, childList: true, subtree: true };
    const callback = (mutationList, observer) => {
      for (const mutation of mutationList) {
        if (
          // if test start from zero
          (!document.querySelector(".spz_7001") &&
            document.querySelector("#b5f35834e0444db6aadeb9fcbae2ece4")) ||
          // test from back buttonW
          (document.querySelector(".spz_7001") &&
            !document.querySelector(".spz_7001 .section2_7001"))
        ) {
          console.log("Interval Working");
          loadTestCode7001();
        }
        // not the target page remove all element
        if (!document.querySelector("#b5f35834e0444db6aadeb9fcbae2ece4")) {
          console.log("not same");

          // remove all element and reset splide and clear interval
          if (document.querySelector(".spz_7001 .main_hero")) {
            document.querySelector(".spz_7001 .main_hero").remove();
          }
          if (document.querySelector(".spz_7001 .features_section")) {
            document.querySelector(".spz_7001 .features_section").remove();
          }
          if (document.querySelector(".spz_7001")) {
            document.querySelector("body").classList.remove("spz_7001");
          }
        }
      }
    };
    const observer = new MutationObserver(callback);
    observer.observe(targetNode, config);
  }
}, 1000);
